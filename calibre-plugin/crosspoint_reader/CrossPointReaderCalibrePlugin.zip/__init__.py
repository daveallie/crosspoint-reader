from .driver import CrossPointDevice


class CrossPointReaderDevice(CrossPointDevice):
    pass
